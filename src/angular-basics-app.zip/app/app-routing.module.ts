import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import  {JokeListComponent}  from './components/joke-list/joke-list.component';
import  {RamComponent}  from './components/ram/ram.component';
import  {JokeDomainComponent}  from './components/joke-domain/joke-domain.component';
import { JokeNestingComponent } from './components/joke-nesting/joke-nesting.component';
import {JokeFormListComponent} from './components/joke-form-list/joke-form-list.component'
import {ProductListComponent} from './components/product-list/product-list.component'
const routes: Routes = [
   { path:'joke-list' , component:JokeListComponent },
   { path:'ram' , component:RamComponent },
   { path:'joke-domain' , component:JokeDomainComponent },
   { path:'joke-nesting' , component:JokeNestingComponent },
   { path:'joke-form-list' , component:JokeFormListComponent },
   { path:'product-list' , component:ProductListComponent }


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
