import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule}  from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RamComponent } from './components/ram/ram.component';
import { JokeListComponent } from './components/joke-list/joke-list.component';
import { JokeDomainComponent } from './components/joke-domain/joke-domain.component';
import { JokeNestingComponent } from './components/joke-nesting/joke-nesting.component';
import { JokeNestingInputComponent } from './components/joke-nesting-input/joke-nesting-input.component';
import { JokeFormComponent } from './components/joke-form/joke-form.component';
import { JokeFormListComponent } from './components/joke-form-list/joke-form-list.component';
import { ProductListComponent } from './components/product-list/product-list.component';

@NgModule({
  declarations: [
    AppComponent,
    RamComponent,
    JokeListComponent,
    JokeDomainComponent,
    JokeNestingComponent,
    JokeNestingInputComponent,
    JokeFormComponent,
    JokeFormListComponent,
    ProductListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
