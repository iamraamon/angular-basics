import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-style-class',
  templateUrl: './ng-style-class.component.html',
  styleUrls: ['./ng-style-class.component.css']
})
export class NgStyleClassComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
