import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.css']
})
export class PipesComponent implements OnInit {

  dateVal: Date;
 // dateVal:Date | undefined;
 // dateVal!: Date;
  constructor() { 

    this.dateVal= new Date();
  }

  ngOnInit(): void {
  }

}
