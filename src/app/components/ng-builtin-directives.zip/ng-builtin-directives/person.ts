export class Person {

    "name": string
    "age": Number
    "country": string
    "dob": Date

    constructor(name: string, age: Number, country: string, dob: Date) {
        this.name = name;
        this.age = age;
        this.country = country;       
        this.dob= dob;
      }
    
}